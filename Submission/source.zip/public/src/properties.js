const UIPORT = 8088;
const NONCELEN = 12;
const DHPRIMELEN = 64; //set this to 128 increases DH cipher strength but it will block UI
const CODELEN = 3;

module.exports.UIPORT = UIPORT;
module.exports.NONCELEN = NONCELEN;
module.exports.DHPRIMELEN = DHPRIMELEN;
module.exports.CODELEN = CODELEN;